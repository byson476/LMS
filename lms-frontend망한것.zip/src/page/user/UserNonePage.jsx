export const UserNonPage = () => {
  return (
    <img src="image/404-error.png"
      alt="에러이미지"
      width="540px"
      height="350px"
      style={{ margin: "10px",opacity:0.2 }}
    />
  );
};
