// src/page/user/UserMainPage.jsx
import React from "react";

const UserMainPage = () => {
  return <div>메인 페이지 테스트</div>;
};

export default UserMainPage;
