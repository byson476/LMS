import React from 'react'

function Footer() {
    return (
        <div id="footer">
            <p align="center">
                Copyright (©) By BySon.[손보연] All rights reserved.
            </p>
        </div>
    )
}

export default Footer