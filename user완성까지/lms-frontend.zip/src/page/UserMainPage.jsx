export const UserMainPage = (props) => {
  return (
    <img src="/image/enter.png"
      alt="메인이미지"
      width="540"
      height="350px"
      style={{ margin: "10px" }}
    />
  );
};
