/*
insert into userinfo(userid,password,name,email) values('guard1','1111','김경호1','guard1@korea.com');
insert into userinfo_role(userinfo_userid, role)  values  ('guard1', 0);
insert into userinfo(userid,password,name,email) values('guard2','2222','김경호2','guard2@korea.com');
insert into userinfo_role(userinfo_userid, role)  values  ('guard2', 0);
insert into userinfo(userid,password,name,email) values('guard3','3333','김경호3','guard3@korea.com');
insert into userinfo_role(userinfo_userid, role)  values  ('guard3', 0);
insert into userinfo_role(userinfo_userid, role)  values  ('guard3', 1);
*/